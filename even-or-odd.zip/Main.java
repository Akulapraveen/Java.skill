public class Main
{
	public static void main(String[] args) {
	    int num= Integer.parseInt(args[0]);
		if(num%2==0)
		    System.out.println("The Given Number "+num+" is Even");
		else
		    System.out.println("The Given Number "+num+" is Odd");
	}
}