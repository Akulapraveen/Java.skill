public class Main
{
	public static void main(String[] args) {
	    int num= Integer.parseInt(args[0]);
		if(num>0)
		    System.out.println("The Given Number "+num+" is Positive");
		else if(num<0)
		    System.out.println("The Given Number "+num+" is Negative");
		else
		    System.out.println("The Given Number "+num+" is Zero");    
	}
}